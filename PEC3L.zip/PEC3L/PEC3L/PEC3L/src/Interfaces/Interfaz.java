package Interfaces;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import CódigoFuente.AcepConexiones;
import CódigoFuente.CreaCompradores;
import CódigoFuente.Logger;
import CódigoFuente.Supermercado;

public class Interfaz extends javax.swing.JFrame {

    private Supermercado s;
    private Boolean parar;
    private ExecutorService acepConexiones;
    private AcepConexiones recibirConexiones;
    private Logger salidaLog;
    private Random rnd = new Random();
    private CreaCompradores c;


    public Interfaz() {

        initComponents();
        s = new Supermercado(20, colaSuperText, colaCarniceriaText1, colaPescaderiaText, colaCajasText, carniceroText, pescaderoText, estantesText, cajera1Text, cajera2Text, salidaLog);
        this.salidaLog=new Logger("evolucionSupermercado.txt", (new Date()).getTime(), s);
        salidaLog.start();
        s.setSalidaLog(salidaLog);
        s.abrirCarniceria();
        s.abrirPescaderia();
        s.abrirCajas();
        this.parar = false;
        this.c = new CreaCompradores(s,salidaLog,20000);
        this.c.start();
        this.recibirConexiones = new AcepConexiones(1234, s);
        this.acepConexiones = Executors.newSingleThreadExecutor();
        acepConexiones.execute(recibirConexiones);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pausaButton = new javax.swing.JButton();
        finButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        colaPescaderiaText = new javax.swing.JTextField();
        carniceroText = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        colaSuperText = new javax.swing.JTextField();
        pescaderoText = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cajera1Text = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        colaCajasText = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cajera2Text = new javax.swing.JTextField();
        estantesText = new javax.swing.JTextField();
        reanudarButton = new javax.swing.JButton();
        colaCarniceriaText1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pausaButton.setText("Pausar");
        pausaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pausaButtonActionPerformed(evt);
            }
        });
        getContentPane().add(pausaButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 100, 40));

        finButton.setText("Finalizar");
        finButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finButtonActionPerformed(evt);
            }
        });
        getContentPane().add(finButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 380, 110, 40));

        jLabel1.setText("Esperando para la pescadería");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 190, 30));

        colaPescaderiaText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colaPescaderiaTextActionPerformed(evt);
            }
        });
        getContentPane().add(colaPescaderiaText, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, 350, -1));

        carniceroText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carniceroTextActionPerformed(evt);
            }
        });
        getContentPane().add(carniceroText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 180, -1));

        jLabel2.setText("Personas esperando para entrar en el supermercado");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 380, 30));

        jLabel3.setText("Carnicero atendiendo a");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 190, 30));

        jLabel4.setText("Esperando para la carnicería");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 190, 30));

        colaSuperText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colaSuperTextActionPerformed(evt);
            }
        });
        getContentPane().add(colaSuperText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 780, -1));

        pescaderoText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pescaderoTextActionPerformed(evt);
            }
        });
        getContentPane().add(pescaderoText, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, 180, -1));

        jLabel5.setText("Pescadero atendiendo a");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 150, 190, 30));

        cajera1Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajera1TextActionPerformed(evt);
            }
        });
        getContentPane().add(cajera1Text, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 140, -1));

        jLabel6.setText("Número de compradores en estantes");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 230, 30));

        jLabel7.setText("Cajera2 atendiendo a");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 320, 190, 30));

        jLabel8.setText("Esperando en cola para cajas");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 190, 30));

        colaCajasText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colaCajasTextActionPerformed(evt);
            }
        });
        getContentPane().add(colaCajasText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 800, -1));

        jLabel9.setText("Cajera1 atendiendo a");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 190, 30));

        cajera2Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cajera2TextActionPerformed(evt);
            }
        });
        getContentPane().add(cajera2Text, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 350, 140, -1));

        estantesText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estantesTextActionPerformed(evt);
            }
        });
        getContentPane().add(estantesText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 30, -1));

        reanudarButton.setText("Reanudar");
        reanudarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reanudarButtonActionPerformed(evt);
            }
        });
        getContentPane().add(reanudarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 380, 100, 40));

        colaCarniceriaText1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colaCarniceriaText1ActionPerformed(evt);
            }
        });
        getContentPane().add(colaCarniceriaText1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 350, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pausaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pausaButtonActionPerformed
        s.pausaCarnicero();
        s.pausaPescadero();
        s.pausaRestSuper();
        pausaButton.setEnabled(false);
        reanudarButton.setEnabled(true);
    }//GEN-LAST:event_pausaButtonActionPerformed

    private void colaPescaderiaTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colaPescaderiaTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_colaPescaderiaTextActionPerformed

    private void carniceroTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carniceroTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carniceroTextActionPerformed

    private void colaSuperTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colaSuperTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_colaSuperTextActionPerformed

    private void pescaderoTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pescaderoTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pescaderoTextActionPerformed

    private void cajera1TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajera1TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajera1TextActionPerformed

    private void colaCajasTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colaCajasTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_colaCajasTextActionPerformed

    private void cajera2TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cajera2TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cajera2TextActionPerformed

    private void estantesTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estantesTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estantesTextActionPerformed

    private void finButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finButtonActionPerformed
        s.finalizar();
        c.interrupt();
        s.cerrrarPescaderia();
        s.cerrarCarniceria();
    }//GEN-LAST:event_finButtonActionPerformed

    private void colaCarniceriaText1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colaCarniceriaText1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_colaCarniceriaText1ActionPerformed

    private void reanudarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reanudarButtonActionPerformed
        reanudarButton.setEnabled(false);
        pausaButton.setEnabled(true);
        s.reanudarPesc();
        s.reanudarCarn();
        s.reanudarRestSuper();
    }//GEN-LAST:event_reanudarButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        acepConexiones.shutdownNow();
        try {
            acepConexiones.awaitTermination(1, TimeUnit.SECONDS);
            salidaLog.interrupt();
            salidaLog.join();
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }

    }//GEN-LAST:event_formWindowClosing

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Interfaz().setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cajera1Text;
    private javax.swing.JTextField cajera2Text;
    private javax.swing.JTextField carniceroText;
    private javax.swing.JTextField colaCajasText;
    private javax.swing.JTextField colaCarniceriaText1;
    private javax.swing.JTextField colaPescaderiaText;
    private javax.swing.JTextField colaSuperText;
    private javax.swing.JTextField estantesText;
    private javax.swing.JButton finButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton pausaButton;
    private javax.swing.JTextField pescaderoText;
    private javax.swing.JButton reanudarButton;
    // End of variables declaration//GEN-END:variables
}
