
package CódigoFuente;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Clase que se utiliza para atender las conexiones entrantes
 */
public class Conexion implements Runnable {

    private Socket socket;
    private DataInputStream entrada;
    private Supermercado supermercado;

    /**
     * Constructor
     * @param socket Socket en el que se establece la conexion
     * @param supermercado simulacion de supermercado
     */
    public Conexion(Socket socket, Supermercado supermercado) { 
        this.socket = socket;
        this.supermercado = supermercado;
        try {
            this.entrada = new DataInputStream(socket.getInputStream()); 
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void run() {
        int aux = -1; //Para evitar errores de inicializacion
        try {
            while (aux != 0) {
                aux = entrada.readInt();
                switch (aux) { //Dependiendo de lo que recibamos a traves del Socket se realizan unas operaciones u otras
                    case 1:
                        supermercado.pausaRestSuper();
                        supermercado.pausaCarnicero();
                        supermercado.pausaPescadero();
                        break;

                    case 2:
                        supermercado.reanudarRestSuper();
                        supermercado.reanudarCarn();
                        supermercado.reanudarPesc();
                        break;

                    case 3:
                        supermercado.pausaCarnicero();
                        break;
                    case 4:
                        supermercado.reanudarCarn();
                        break;
                    case 5:
                        supermercado.pausaPescadero();
                        break;
                    case 6:
                        supermercado.reanudarPesc();
                        break;

                }
            }
            entrada.close();
            socket.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}

