
package CódigoFuente;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *Clase que se usada para crear un Runnable
 * que se dedica a crear un socket y a esperar
 * y a aceptar conexiones en el mismo
 */
public class AcepConexiones implements Runnable{
    private ServerSocket acepConexiones;
    private ExecutorService conexiones;
    private Supermercado supermercado;
    
    /**
     * Constructor
     * @param puerto Numero de puerto en el que se escucharan peticiones de conexion
     * @param supermercado Objeto supermercado que se pretende controlar
     */
    public AcepConexiones(int puerto , Supermercado supermercado){
        try {
            this.acepConexiones=new ServerSocket(puerto); 
            this.conexiones=Executors.newCachedThreadPool(); //Pool de hilos que atenderan las conexiones
            this.supermercado=supermercado;
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void run(){
        while(!Thread.interrupted()){ //Atendera peticiones de conexión mientras no sea interrumpido
            try {
                Socket socket=acepConexiones.accept();
                Conexion cliente=new Conexion(socket, supermercado); //Al aceptar una conexión creamos un objeto Cliente, al cual le pasamos el socket por el que se van a recibir todas las ordenes emitidas por el cliente 
                conexiones.execute(cliente); //Y se lo pasamos al pool para que se encargue de ejecutarlo (objeto Cliente implementa interfaz Runnable)
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
        try {
            conexiones.shutdownNow();
            conexiones.awaitTermination(10, TimeUnit.SECONDS);
            acepConexiones.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        catch(InterruptedException ie){
            System.out.println(ie.getMessage());
        }
    }
    
}
