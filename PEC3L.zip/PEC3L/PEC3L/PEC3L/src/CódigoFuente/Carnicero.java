
package CódigoFuente;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Exchanger;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JTextField;

/**
 * Simulacion del comportamiento de un carnicero
 */
public class Carnicero extends Thread {

    private Random rnd = new Random();
    private JTextField atendiendoC;
    private CountDownLatch pausaCarn;
    private AtomicBoolean pausarCarn;
    private Logger salidaLog;
    private CyclicBarrier despachado;
    private Exchanger<String> aux;
    private long t0;
    private long tf;
    private long tiempo;
    private static int nPersAtendidas = 0;
    private static long tiempoAcum = 0;

    /**
     * Constructor
     *
     * @param despachado CyclicBarrier en la que el comprador puede esperar a
     * que el Carnicero termine de atenderle
     * @param atendiendoC JTextField en el que el carnicero muestra a quien esta
     * atendiendo
     * @param pausaCarn CountDownLatch mediante el que se puede pausar al
     * carnicero
     * @param pausarCarn AtomicBoolean mediante el cual se puede dar la orden de
     * pausa del carnicero
     * @param salidaLog
     * @param aux
     */
    public Carnicero(CyclicBarrier despachado, JTextField atendiendoC, CountDownLatch pausaCarn, AtomicBoolean pausarCarn, Logger salidaLog, Exchanger<String> aux) {
        this.despachado = despachado;
        this.atendiendoC = atendiendoC;
        this.pausaCarn = pausaCarn;
        this.pausarCarn = pausarCarn;
        this.salidaLog = salidaLog;
        this.aux = aux;
    }

    public void setSalidaLog(Logger salidaLog) {
        this.salidaLog = salidaLog;
    }

    public void setPausaCarn(CountDownLatch pausaCarn) {
        this.pausaCarn = pausaCarn;
    }

    public synchronized static long getTiempoAcum() {
        return tiempoAcum;
    }

    /**
     * Suma al total de tiempo que el carnicero ha estado atendiendo a
     * compradores lo que se le pase por parametro. Tambien incrementa en uno el
     * total de compradores atendidos
     *
     * @param tiempo tiempo que se va a sumar al total
     */
    public synchronized static void annadirTiempo(long tiempo) {
        Carnicero.nPersAtendidas++;
        Carnicero.tiempoAcum += tiempo;
    }

    /**
     * Calcula la media de tiempo
     *
     * @return la media
     */
    public synchronized static double mediaTiempo() {
        return tiempoAcum / nPersAtendidas;
    }

    @Override
    public void run() {
        String idComprador = "";
        try {
            while (!interrupted()) {
                if (pausarCarn.get()) {
                    pausaCarn.await();
                }
                atendiendoC.setText("");
                idComprador = aux.exchange(""); //El carnicero se quedara esperando a que llegue un comprador y le proporcione su nombre
                atendiendoC.setText(idComprador);
                this.t0 = new Date().getTime();
                System.out.println("Carnicero atendiendo a " + idComprador + " en el instante " + t0);
                salidaLog.annadirTexto("Carnicero atendiendo a " + idComprador + " en el instante " + t0);
                Thread.sleep(1500 + rnd.nextInt(1001)); //Simulamos atender al comprador
                this.tf = new Date().getTime();
                this.tiempo = tf - t0; //Calculamos el tiempo
                Carnicero.annadirTiempo(tiempo);
                System.out.println(idComprador + " deja la carniceria en el instante " + tf);
                salidaLog.annadirTexto(idComprador + " deja la carniceria en el instante " + tf);
                System.out.println(idComprador + " ha estado en la carniceria " + tiempo);
                salidaLog.annadirTexto(idComprador + " ha estado en la carniceria " + tiempo);
                despachado.await(); //comprador espera a que el carnnicero termine de atenderle

            }

        } catch (InterruptedException ex) {
            System.out.println("Carnicero interrumpido");
            salidaLog.annadirTexto("Carnicero interrumpido");
            try {
                despachado.await();
                atendiendoC.setText("");
            } catch (InterruptedException ex1) {
                System.out.println(ex1.getMessage());
            } catch (BrokenBarrierException ex1) {
                System.out.println(ex1.getMessage());
            } catch (ArithmeticException ae) {
                salidaLog.annadirTexto("Numero de personas que han salido es 0 y no se puede obtener la media por persona");
            }

        } catch (BrokenBarrierException bbe) {
            System.out.println(bbe.getMessage());
        }

    }

}
