package CódigoFuente;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Exchanger;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JTextField;

public class Supermercado {

    private int capacidad;
    private Semaphore entrada;
    private Cajera cajera1;
    private Cajera cajera2;
    private Random rnd = new Random();
    private Integer persEstantes;
    private Integer persSuperE;
    private Integer persSuperS;
    private List<Comprador> colaSupermercado;
    private List<Comprador> colaCarniceria;
    private List<Comprador> colaPescaderia;
    private List<String> colaCajas;
    private JTextField colaSuper;
    private JTextField colaCarn;
    private JTextField colaPesc;
    private JTextField colaCaj;
    private JTextField atendiendoC;
    private JTextField atendiendoP;
    private JTextField estantes;
    private JTextField atendiendoCa1;
    private JTextField atendiendoCa2;
    private AtomicBoolean pausarCarn;
    private CountDownLatch pausaCarn;
    private AtomicBoolean pausarPesc;
    private CountDownLatch pausaPesc;
    private AtomicBoolean pausarRestSuper;
    private CountDownLatch pausaRestSuper;
    private boolean pescCerrada;
    private boolean carnCerrada;
    private Logger salidaLog;
    private Semaphore semCarn;
    private Semaphore semPesc;
    private Semaphore semCaj;
    private Semaphore semCaj1;
    private Semaphore semCaj2;
    private Carnicero carnicero;
    private CyclicBarrier despachadoCarn;
    private CyclicBarrier atendidoC1;
    private CyclicBarrier atendidoC2;
    private Exchanger<String> exchCarn;
    private Exchanger<String> exchCaj1;
    private Exchanger<String> exchCaj2;
    private Pescadero pescadero;
    private CyclicBarrier despachadoPesc;
    private Exchanger<String> exchPesc;

    /**
     * Constructor
     * @param capacidad numero de compradores que entran en el super
     * @param colaSuper JTextField en el que se muestra la cola de entrada al super
     * @param colaCarniceria JTextField en el que se muestra la cola de la carniceria
     * @param colaPescaderia JTextField en el que se muestra la cola de la pescaderia
     * @param colaCaj JTextField en el que se muestra la cola de las cajas
     * @param atendiendoC JTextField en el que se muestra a quien esta atendiendo el carnicero
     * @param atendiendoP JTextField en el que se muestra a quien esta atendiendo el pescadero
     * @param estantes JTextField en el que se muestra cuantos compradores hay en los estantes
     * @param atendiendoCa1 JTextField en el que se muestra a quien esta atendiendo la cajera 1
     * @param atendiendoCa2 JTextField en el que se muestra a quien esta atendiendo la cajera 2
     * @param salidaLog Logger con el que se escribe en el fichero de texto
     */
    public Supermercado(int capacidad, JTextField colaSuper, JTextField colaCarniceria, JTextField colaPescaderia, JTextField colaCaj, JTextField atendiendoC, JTextField atendiendoP,
            JTextField estantes, JTextField atendiendoCa1, JTextField atendiendoCa2, Logger salidaLog) {
        this.capacidad = capacidad;
        this.entrada = new Semaphore(capacidad, true);
        this.persEstantes = 0;
        this.persSuperE = 0;
        this.persSuperS = 0;
        this.colaSupermercado = Collections.synchronizedList(new ArrayList());
        this.colaCarniceria = Collections.synchronizedList(new ArrayList());
        this.colaPescaderia = Collections.synchronizedList(new ArrayList());
        this.colaCajas = Collections.synchronizedList(new ArrayList());
        this.colaSuper = colaSuper;
        this.colaCarn = colaCarniceria;
        this.colaPesc = colaPescaderia;
        this.colaCaj = colaCaj;
        this.atendiendoC = atendiendoC;
        this.atendiendoP = atendiendoP;
        this.estantes = estantes;
        this.atendiendoCa1 = atendiendoCa1;
        this.atendiendoCa2 = atendiendoCa2;
        this.pausarCarn = new AtomicBoolean();
        this.pausarCarn.set(false);
        this.pausaCarn = new CountDownLatch(1);
        this.pausarPesc = new AtomicBoolean();
        this.pausarPesc.set(false);
        this.pausaPesc = new CountDownLatch(1);
        this.pausarRestSuper = new AtomicBoolean();
        this.pausarRestSuper.set(false);
        this.pausaRestSuper = new CountDownLatch(1);
        this.salidaLog = salidaLog;
        this.semCarn = new Semaphore(1, true);
        this.semPesc = new Semaphore(1, true);
        this.despachadoCarn = new CyclicBarrier(2);
        this.exchCarn = new Exchanger<String>();
        this.carnicero = new Carnicero(despachadoCarn, atendiendoC, pausaCarn, pausarCarn, this.salidaLog, exchCarn);
        this.despachadoPesc = new CyclicBarrier(2);
        this.exchPesc = new Exchanger<String>();
        this.pescadero = new Pescadero(despachadoPesc, atendiendoP, pausaPesc, pausarPesc, this.salidaLog, exchPesc);
        this.atendidoC1 = new CyclicBarrier(2);
        this.atendidoC2 = new CyclicBarrier(2);
        this.exchCaj1 = new Exchanger<String>();
        this.exchCaj2 = new Exchanger<String>();
        this.semCaj1 = new Semaphore(1);
        this.semCaj2 = new Semaphore(1);
        this.cajera1 = new Cajera(1, atendidoC1, colaCajas, atendiendoCa1, colaCaj, pausaRestSuper, pausarRestSuper, this.salidaLog, exchCaj1);
        this.cajera2 = new Cajera(2, atendidoC2, colaCajas, atendiendoCa2, colaCaj, pausaRestSuper, pausarRestSuper, this.salidaLog, exchCaj2);
        this.semCaj = new Semaphore(2, true);
        this.pescCerrada = false;
        this.carnCerrada = false;
    }
    
    /**
     * Cuando el supermercado no esta lleno permite al Comprador pasado
     * como parametro pasar, si estuviera lleno se le incorporaria a
     * una cola, en la cual esperara que sea su turno y que haya hueco
     * disponible dentro del supermercado
     * @param comprador Comprador que desea entrar al supermercado
     * @return true si no se ha podido entrar, false si se ha podido entrar
     */
    public boolean entrar(Comprador comprador) {
        try {
            if (pausarRestSuper.get()) { //Si el booleano esta activo los compradores que todavía no han llegado al supermercado se quedaran pausados
                pausaRestSuper.await();
            }
            colaSupermercado.add(comprador); //Incorporamos a los compradores a la cola de entrada al supermercado
            actualizaColaSuper();
            entrada.acquire(); //Si no hay espacio disponible en el supermercado, los compradores se quedaran bloqueados en este punto
            if (pausarRestSuper.get()) { //Si el booleano esta activo los compradores se pausaran antes de entrar al super
                pausaRestSuper.await();
            }
            colaSupermercado.remove(comprador); //Los compradores salen de la cola y acceden al super
            colaSuper.setText(colaSupertoString());
            System.out.println(comprador.getIdentificacion() + " entra al supermercado");
            salidaLog.annadirTexto(comprador.getIdentificacion() + " entra al supermercado");
            System.out.println("Personas que han entrado: " + persSuperE);
            salidaLog.annadirTexto("Personas que han entrado: " + persSuperE);
            return false;
        } catch (InterruptedException ex) { //Si los compradores han sido interrumpidos
            System.out.println(comprador.getIdentificacion() + " :supermercado cerrado");
            salidaLog.annadirTexto(comprador.getIdentificacion() + " :supermercado cerrado");
            colaSupermercado.remove(comprador); //Son sacados de la cola sin que puedan entrar al supermercado
            actualizaColaSuper();
            return true;

        }

    }
    
    /**
     * El comprador pasado como paraametro abandona el supermercado
     * @param comprador Commprador que desea salir
     * @return Numero de compradores que ya han salido durante la ejecucion de la simulacion
     */
    public Integer salir(Comprador comprador) {
        persSuperS++;
        entrada.release(); //Si hay algun comprador esperando en la cola sera desbloqueado
        return persSuperS;
    }
    
    /**
     * El comprador pasado como parametro entrara en la 
     * carniceria, si el carnicero estuviera ocupado
     * (solo hay uno) el comprador seria incorporado
     * a una cola de espera
     * @param comprador Comprador que desea entrar a la carniceria
     */
    public void irCarniceria(Comprador comprador) {
        if (!this.isCarnCerrada()) { //Si la carniceria esta cerrada no puede entrar
            colaCarniceria.add(comprador); //Ponemos en la cola al comprador
            try {
                synchronized (colaCarn) {
                    colaCarn.setText(this.colaCarntoString());
                }
                System.out.println(comprador.getIdentificacion() + " entra a la carniceria");
                salidaLog.annadirTexto(comprador.getIdentificacion() + " entra a la carniceria");
                semCarn.acquire(); //Esperamos a que el carnicero pueda atendernos (que el carnicero este libre)
                exchCarn.exchange(comprador.getIdentificacion()); //Pasamos el nombre del comprador al carnicero
                colaCarniceria.remove(comprador); //Sacamos de la cola al comprador
                synchronized (colaCarn) {
                    colaCarn.setText(this.colaCarntoString());
                }
                despachadoCarn.await(); //Esperamos a que el carnicero termine de atendernos
            } catch (InterruptedException ex) { //Si los compradores que estaban esperando en la cola de la carniceria son interrumpidos 
                System.out.println(ex.getMessage());
                colaCarniceria.remove(comprador); //Son sacados de la cola sin pasar por el carnicero
                synchronized (colaCarn) {
                    colaCarn.setText(this.colaCarntoString());
                }
            } catch (BrokenBarrierException bbe) {
                System.out.println(bbe.getMessage());
            } finally {
                semCarn.release(); //Damos paso al siguiente comprador
            }

        } else {
            System.out.println("Carniceria cerrada");
        }
    }
    /**
     * El comprador que sea pasado como parametro entrara a
     * la pescaderia, si el pecadero esta libre, este le atendera
     * al instante, sino sera puesto en una cola en la que esperara
     * que el pescadero pueda atenderle
     * @param comprador Comprador que desea entrar a la pescaderia
     */
    public void irPescaderia(Comprador comprador) {

        if (!this.isPescCerrada()) { //Si la pescaderia esta cerrada los compradores no podran pasar
            colaPescaderia.add(comprador); //Metemos al comprador en la cola de espera
            try {
                synchronized (colaPesc) {
                    colaPesc.setText(this.colaPesctoString());
                }
                System.out.println(comprador.getIdentificacion() + " entra a la pescaderia");
                salidaLog.annadirTexto(comprador.getIdentificacion() + " entra a la pescaderia");
                semPesc.acquire(); //Pescadero libre u ocupado
                exchPesc.exchange(comprador.getIdentificacion()); //El comprador pasa su nombre al pescadero
                colaPescaderia.remove(comprador); //El comprador sale de la cola de espera
                synchronized (colaPesc) {
                    colaPesc.setText(this.colaPesctoString());
                }
                despachadoPesc.await(); //Esperamos a que el pescadero termine de atendernos
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());
                colaPescaderia.remove(comprador);
                synchronized (colaPesc) {
                    colaPesc.setText(this.colaPesctoString());
                }
            } catch (BrokenBarrierException bbe) {
                System.out.println(bbe.getMessage());
            } finally {
                semPesc.release(); //Damos paso al siguiente comprador
            }
        } else {
            System.out.println("Pescaderia cerrada");
        }
    }
    
    /**
     * Los compradores que ejecuten este metodo entraran
     * a los estantes directamente, ya que aqui no hay
     * ninguna restriccion de espacio
     * @param identificador ID del comprador que desea entrar a los estantes
     */
    public void irEstantes(String identificador) {
        synchronized (persEstantes) {
            if (pausarRestSuper.get()) { //Si el booleano esta activo los compradores se detendran antes de entrar en los estantes
                try {
                    pausaRestSuper.await();
                } catch (InterruptedException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            persEstantes++;
            estantes.setText(Integer.toString(persEstantes));
            System.out.println(identificador + " mira los estantes");
            salidaLog.annadirTexto(identificador + " mira los estantes");
            System.out.println("Personas en los estantes: " + persEstantes);
            salidaLog.annadirTexto("Personas en los estantes: " + persEstantes);
        }
        try {
            Thread.sleep(1000 + rnd.nextInt(10001)); //El comprador simula estar mirando los estantes
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
        synchronized (persEstantes) {
            if (pausarRestSuper.get()) { //Si el booleano esta activo los compradores se detendran antes de salir de los estantes
                try {
                    pausaRestSuper.await();
                } catch (InterruptedException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            persEstantes--;
            System.out.println(identificador + " deja los estantes");
            salidaLog.annadirTexto(identificador + " deja los estantes");
            System.out.println("Personas en los estantes: " + persEstantes);
            salidaLog.annadirTexto("Personas en los estantes: " + persEstantes);
            estantes.setText(Integer.toString(persEstantes));
        }
    }

    /**
     * Encamina a los compradores a la zona de cajas para
     * que paguen, si todas las cajeras estan ocupadas esperaran
     * a que alguna este libre en una cola
     * @param identificador ID del comprador que tiene que pagar
     */
    public void pagar(String identificador) {
        boolean atendido = false;
        if (pausarRestSuper.get()) { //Si el booleano esta activo, los compradores se detendran antes de entar en la zona de cajas
            try {
                pausaRestSuper.await();
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());
            }
        }
        colaCajas.add(identificador); //Ponemos en la cola a los compradores
        System.out.println(identificador + " va a pagar");
        salidaLog.annadirTexto(identificador + " va a pagar");
        synchronized (colaCaj) {
            colaCaj.setText(colaCajas.toString());
        }
        try {
            while (!atendido) {
                semCaj.acquire(); //Si no hay cajeras libres los compradores se quedaran bloqueados, y cuando un comprador se desbloquea
                if (semCaj1.tryAcquire()) { //Mira si la cajera 1 esta , si lo esta
                    exchCaj1.exchange(identificador); //Le pasamos el nombre del comprador
                    colaCajas.remove(identificador); //Sacamos al comprador de la cola
                    atendidoC1.await(); //Esperamos que la cajera nos termine de atender
                    semCaj1.release();
                    semCaj.release(); //Y abandonamos la zona de cajas
                    atendido = true;
                } else if (semCaj2.tryAcquire()) { //Si la cajera 1 no esta libre, miramos que la cajera 2 este libre, sino estuviera volveriamos a la cola, pero si esta
                    exchCaj2.exchange(identificador); //Le pasamos el nombre del comprador
                    colaCajas.remove(identificador); //Sacamos al comprador de la cola
                    atendidoC2.await(); //Esperamos que la cajera termine de atendernos
                    semCaj2.release();
                    semCaj.release(); //Y abandonamos la zona de cajas
                    atendido = true;
                }
            }

        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        } catch (BrokenBarrierException bbe) {
            System.out.println(bbe.getMessage());
        }
    }
    
    /**
     * Muestra en el JTextField de la cola de entrada al
     * supermercado la cola que hay, tambien aumenta en uno
     * el numero de compradores que han entrado al supermercado
     */
    public synchronized void actualizaColaSuper() { //Evita que dos o mas hilos accedan a la vez al TextField colaSuper
        persSuperE++;
        colaSuper.setText(colaSupertoString());
    }

    /**
     * Cierra la carniceria y la pescaderia e interrumpe
     * a los compradores que estaban en la cola de entrada al super
     */
    public void finalizar() {
        for (int i = 0; i < colaSupermercado.size(); i++) {
            colaSupermercado.get(i).interrupt(); //Interrumpimos a los hilos que estan en la cola de entrada al supermercado
        }
        this.cerrrarPescaderia();
        this.cerrarCarniceria();
    }

    
    public synchronized String colaSupertoString() {
        String s = "";
        for (int i = 0; i < colaSupermercado.size(); i++) {
            s = s + " " + colaSupermercado.get(i).getIdentificacion(); //Tomamos los nombres de los compradores que estan en la cola de entrada al super
        }
        return s;
    }

    public synchronized String colaCarntoString() {
        String s = "";
        for (int i = 0; i < colaCarniceria.size(); i++) {
            s = s + " " + colaCarniceria.get(i).getIdentificacion(); //Tomamos los nombres de los compradores que estan en la cola de la carniceria
        }
        return s;
    }

    public synchronized String colaPesctoString() {
        String s = "";
        for (int i = 0; i < colaPescaderia.size(); i++) {
            s = s + " " + colaPescaderia.get(i).getIdentificacion(); //Tomamos los nombres de los compradores que estan en la cola de la pescaderia
        }
        return s;
    }

    
    public void pausaCarnicero() {
        this.pausarCarn.set(true); //Activa el booleano que pausa al carnicero
    }

    
    public void pausaPescadero() {
        this.pausarPesc.set(true); //Activa el booleano que pausa al pescadero
    }

    
    public void pausaRestSuper() {
        this.pausarRestSuper.set(true); //Activa el booleano que pausa al resto del super
    }

    
    public void reanudarCarn() {
        this.pausarCarn.set(false); //Desactivamos el booleano de pausa del carnicero
        this.pausaCarn.countDown(); //Al hacer countDown desbloqueamos al carnicero
        this.pausaCarn = new CountDownLatch(1); //Como los CountDownLAtch no son reutilizables, creamos uno nuevo
        carnicero.setPausaCarn(pausaCarn); //Y se lo pasamos al carnicero
    }

    public void reanudarRestSuper() {
        this.pausarRestSuper.set(false); //Desactivamos el booleano de pausa del resto del super
        this.pausaRestSuper.countDown(); //Cuando hacemos countDown se desbloquea el resto del supermecado
        this.pausaRestSuper = new CountDownLatch(1); //Como el CountDownLatch no es reutilizable, creamos uno nuevo
        cajera1.setPausaCaj(pausaRestSuper); //Y se lo pasamos a las dos cajeras
        cajera2.setPausaCaj(pausaRestSuper);
    }

    public void reanudarPesc() { 
        this.pausarPesc.set(false); //Desactivamos el booleano que pausa al pescadero
        this.pausaPesc.countDown(); //Al hacer countDown se desbloquea el pescadero
        this.pausaPesc = new CountDownLatch(1); //Como el CountDownLatch no es reutilizable, creamos uno nuevo
        pescadero.setPausaPesc(pausaPesc); //Y se lo pasamos al pescadero
    }

    public synchronized Integer getPersSuperE() {
        return persSuperE;
    }

    public synchronized Integer getPersSuperS() {
        return persSuperS;
    }

    public synchronized void setSalidaLog(Logger salidaLogger) {
        this.salidaLog = salidaLogger;
        carnicero.setSalidaLog(salidaLog);
        pescadero.setSalidaLog(salidaLog);
        cajera1.setSalidaLog(salidaLog);
        cajera2.setSalidaLog(salidaLog);
    }

    public void abrirCarniceria() {
        carnicero.start();
    }

    public void abrirPescaderia() {
        pescadero.start();
    }

    public void abrirCajas() {
        cajera1.start();
        cajera2.start();
    }

    
    public synchronized void cerrrarPescaderia() {
        pescadero.interrupt(); //Interrumpimos al pescadero
        pescCerrada = true;
        for (int i = 0; i < colaPescaderia.size(); i++) {
            colaPescaderia.get(i).interrupt(); //Interrumpimos a todos los compradores que estan en la cola de la pescaderia
        }
    }

    public synchronized boolean isPescCerrada() {
        return pescCerrada;
    }

    public synchronized void cerrarCarniceria() {
        carnicero.interrupt(); //Interrumpimos al carnicero
        carnCerrada = true;
        for (int i = 0; i < colaCarniceria.size(); i++) {
            colaCarniceria.get(i).interrupt(); //Interrumpimos a los compradores que estan en la cola de la carniceria
        }
    }

    public synchronized boolean isCarnCerrada() {
        return carnCerrada;
    }

}
