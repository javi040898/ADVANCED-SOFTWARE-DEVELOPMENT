package CódigoFuente;

import java.util.List;
import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Exchanger;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JTextField;

/**
 * Clase que simula el comportamiento de una cajera
 */
public class Cajera extends Thread {

    private String identificacion;
    private Random rnd = new Random();
    private CyclicBarrier atendido;
    private List<String> colaCajas;
    private JTextField colaCaj;
    private JTextField atendiendoCa;
    private CountDownLatch pausaCaj;
    private AtomicBoolean pausarCaj;
    private Logger salidaLog;
    private Exchanger<String> exchCaj;
    
    /**
     * Constructor
     * @param identificador id de la cajera
     * @param atendido CyclicBarrier con la que los clientes pueden esperar a que la cajera les atienda
     * @param colaCajas Cola de espera en las cajas
     * @param atendiendoCa JTextField en el que la cajera muestra a quien esta atendiendo
     * @param colaCaj JTexField en el que se muestra la cola de espera de las cajas
     * @param pausaCaj CountDownLatch que pausa a la cajera cuando se da la orden
     * @param pausarCaj AtomicBoolean mediante el cual se puede dar la orden de pausa
     * @param salidaLog Logger mediante el cual podemos escribir en el fichero de texto
     * @param exchCaj Exchanger mediante el cual la cajera puede obtener el nombre del comprador al que esta atendiendo
     */
    public Cajera(int identificador, CyclicBarrier atendido, List<String> colaCajas, JTextField atendiendoCa, JTextField colaCaj,
            CountDownLatch pausaCaj, AtomicBoolean pausarCaj, Logger salidaLog, Exchanger exchCaj) {
        this.identificacion = "Cajera" + Integer.toString(identificador);
        this.atendido = atendido;
        this.colaCaj = colaCaj;
        this.colaCajas = colaCajas;
        this.atendiendoCa = atendiendoCa;
        this.pausarCaj = pausarCaj;
        this.pausaCaj = pausaCaj;
        this.salidaLog = salidaLog;
        this.exchCaj = exchCaj;
    }

    public void setSalidaLog(Logger salidaLog) {
        this.salidaLog = salidaLog;
    }

    public void setPausaCaj(CountDownLatch pausaCaj) {
        this.pausaCaj = pausaCaj;
    }
    

    @Override
    public void run() {
        String idComprador = "";
        while (!interrupted()) {
            try {
                if (pausarCaj.get()) { //Si el booleano esta activo la cajera se pausara
                    pausaCaj.await();
                }
                atendiendoCa.setText("");
                idComprador = exchCaj.exchange(""); //Aqui obtenemos el id del comprador que estamos atendiendo (esperamos a que el comprador nos lo suministre)
                System.out.println(identificacion + " atendiendo a " + idComprador);
                salidaLog.annadirTexto(identificacion + " atendiendo a " + idComprador);
                synchronized (colaCaj) {
                    colaCaj.setText(colaCajas.toString());
                }
                atendiendoCa.setText(idComprador);
                Thread.sleep(3000 + rnd.nextInt(2001)); //Simulamos atender al comprador
                atendido.await();  //Aqui el comprador esperara a que terminemos de atenderle
            } catch (InterruptedException ex) {
                System.out.println("Cajera interrumpida");
                salidaLog.annadirTexto("Cajera interrumpida");
            } catch (BrokenBarrierException bbe) {
                System.out.println(bbe.getMessage());
            }
        }
    }
}
