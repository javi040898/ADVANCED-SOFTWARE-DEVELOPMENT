
package CódigoFuente;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

/**
 * Clase que maneja el PrintStream que escibe en
 * el fichero de texto
 */
public class Logger extends Thread {

    private PrintStream salida;
    private ConcurrentLinkedQueue<String> buffer; //Cola no bloqueante
    private Semaphore bufferVacio;
    private Supermercado s;
    private long t0; //Timestamp del inicio del programa

    /**
     * Constructor
     * @param nomArchivo nombre del archivo en el que se guardara todo el texto que se le pase a esta clase
     * @param t0 timespamp del inicio de la simulacion
     * @param s objeto supermercado
     */
    public Logger(String nomArchivo, long t0, Supermercado s) {
        try {
            salida = new PrintStream("./" + nomArchivo);
            this.t0 = t0;
            this.s = s;
            buffer = new ConcurrentLinkedQueue<String>();
            this.bufferVacio = new Semaphore(0); //EL numero de permisos coincide con el numero de elementos que tiene la cola, asi si la cola esta vacia el hilo que imprime en el log se bloqueara
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * El texto que se pasa como parametro se 
     * pone en cola para ser pasado al archivo
     * de texto
     * @param texto texto que se desea plasmar en el archivo de texto
     */
    public void annadirTexto(String texto) {
        long tActual = new Date().getTime();
        buffer.offer(tActual + " seg:" + (tActual - t0) + " " + texto);
        bufferVacio.release();
    }

    public void run() {
        try {
            while (!interrupted()) { //Mientras no sea interrumpido

                bufferVacio.acquire(); //Si el buffer de texto no esta vacio (si esta vacio el hilo se queda bloqueado)

                salida.println(buffer.poll()); //Lo imprimimos en el archivo
            }
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
            salida.println("Tiempo medio de servicio del carnicero: " + Carnicero.mediaTiempo());
            salida.println("Tiempo medio de servicio del pescadero: " + Pescadero.mediaTiempo());
            salida.println("Tiempo acumulado de servicio del carnicero: " + Carnicero.getTiempoAcum());
            salida.println("Tiempo acumulado de servicio del pescadero: " + Pescadero.getTiempoAcum());
            salida.println("Numero personas que han entrado: " + s.getPersSuperE());
            salida.println("Numero personas que han salido: " + s.getPersSuperS());
            try{
                salida.println("Tiempo medio desde que llega un comprador a la fila del super hasta que sale: " + Comprador.mediaLS());
                salida.println("Tiempo medio desde que entra en el super un comprador hasta que sale" + Comprador.mediaES());
            }
            catch(ArithmeticException ae){
                salida.println("Numero de personas que han salido es 0 y no se puede obtener la media por persona");
            }


        }
        salida.close();
    }
}
