package CódigoFuente;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class Comprador extends Thread {

    private Random rnd = new Random();
    private String identificacion;
    private Supermercado supermercado;
    private Semaphore despachado;
    private Logger salidaLog;
    private long t0;
    private long t1;
    private long tf;
    private long entrarSalir;
    private long llegarSalir;
    //Variables estaticas para que sean variables comunes a todos los compradores
    private static int nES = 0;
    private static int nLS = 0;
    private static long tiempoTotalES = 0;
    private static long tiempoTotalLS = 0;

    /**
     * Constructor
     * @param identificacion id del comprador
     * @param supermercado simulacion del supermercado
     * @param salidaLog Logger mediante el cual se puede escribir en el fichero de texto
     */
    public Comprador(int identificacion, Supermercado supermercado, Logger salidaLog) {
        this.identificacion = "Comprador" + Integer.toString(identificacion);
        this.supermercado = supermercado;
        despachado = new Semaphore(0);
        this.tf = tf;
        this.t0 = t0;
        this.t1 = t1;
        this.entrarSalir = entrarSalir;
        this.llegarSalir = llegarSalir;
        this.tiempoTotalES = tiempoTotalES;
        this.salidaLog = salidaLog;

    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    /**
     * Suma al total de tiempos desde que un cliente entra
     * al supermercado hasta que sale lo que se le pase 
     * como parametro.
     * Ademas incrementa en uno el numero de tiempos
     * @param tiempo tiempo que se va a sumar
     */
    public synchronized static void annadirTiempoMediaES(long tiempo) {
        tiempoTotalES += tiempo;
        nES++;
    }

     /**
     * Suma al total de tiempos desde que un cliente llega
     * al supermercado hasta que sale lo que se le pase 
     * como parametro.
     * Ademas incrementa en uno el numero de tiempos
     * @param tiempo tiempo que se va a sumar
     */
    public synchronized static void annaditTiempoMediaLS(long tiempo) {
        tiempoTotalLS += tiempo;
        nLS++;
    }

    /**
     * Calcula la media de los tiempos desde 
     * que los Compradores entran en el super
     * hasta que salen
     * @return la media
     */
    public synchronized static double mediaES() {
        return tiempoTotalES / nES;
    }
    
    /**
     * Calcula la media de tiempos desde que los
     * Compradores llegan al super hasta que salen
     * @return la media
     */
    public synchronized static double mediaLS() {
        return tiempoTotalLS / nLS;
    }

    /**
     * @return La suma del total de los 
     * tiempos desde que los Compradores
     * entran al supermercado hasta
     * que salen
     */
    public synchronized static long getTiempoTotalES() {
        return tiempoTotalES;
    }

    /**
     * @return La suma del total de los tiempos
     * desde que los clientes llegan al super
     * hasta que salen
     */
    public synchronized static long getTiempoTotalLS() {
        return tiempoTotalES;
    }

    @Override
    public void run() {
        boolean noEntrar = false;

        this.t1 = new Date().getTime();
        System.out.println(identificacion + " llega al supermercado en el instante " + t1);
        salidaLog.annadirTexto(identificacion + " llega al supermercado en el instante " + t1);

        noEntrar = supermercado.entrar(this); //Esto es para que cuando se de la orden de finalizar la simulacion, los compradores que todavia estan en la cola para entrar al supermercado no entren
        if (!noEntrar) { 
            this.t0 = new Date().getTime();
            System.out.println(identificacion + " entra en el instante " + t0);
            salidaLog.annadirTexto(identificacion + " entra en el instante " + t0);
            switch (rnd.nextInt(3)) { //El comprador decide donde ir
                case 0:
                    supermercado.irCarniceria(this);
                    break;
                case 1:
                    supermercado.irPescaderia(this);
                    break;
                case 2:
                    supermercado.irEstantes(identificacion);
            }
            supermercado.pagar(identificacion);
        }
        Integer s = supermercado.salir(this);
        this.tf = new Date().getTime();
        System.out.println(identificacion + " sale en el instante " + tf);
        salidaLog.annadirTexto(identificacion + " sale en el instante " + tf);
        System.out.println("Compradores que han salido: " + s);
        salidaLog.annadirTexto("Compradores que han salido: " + s);
        this.entrarSalir = (tf - t0);
        Comprador.annadirTiempoMediaES(entrarSalir);
        this.llegarSalir = (tf - t1);
        Comprador.annaditTiempoMediaLS(llegarSalir);
        System.out.println(identificacion + " ha estado desde que ha entrado hasta que ha salido " + entrarSalir);
        salidaLog.annadirTexto(identificacion + " ha estado desde que ha entrado hasta que ha salido " + entrarSalir);
        System.out.println("Tiempo total de todos los comprados: " + tiempoTotalES);
        salidaLog.annadirTexto("Tiempo total de todos los comprados: " + tiempoTotalES);
        System.out.println(identificacion + " ha estado desde que ha llegado hasta que ha salido " + llegarSalir);
        salidaLog.annadirTexto(identificacion + " ha estado desde que ha llegado hasta que ha salido " + llegarSalir);
    }

}
