package CódigoFuente;

import java.util.Random;

/**
 * Clase que crea un hilo que crea compradores
 */
public class CreaCompradores extends Thread {

    private Random rnd = new Random();
    private Supermercado s;
    private Logger salidaLog;
    private int cantidad;

    /**
     * Constructor
     * @param s simulacion del supermercado
     * @param salidaLog Logger mediante el cual se puede escribir en el fichero de texto
     * @param cantidad cantidad de compradores que se desean crear
     */
    public CreaCompradores(Supermercado s, Logger salidaLog, int cantidad) {

        this.s = s;
        this.salidaLog = salidaLog;
        this.cantidad = cantidad;
    }

    /**
     * Crea el numero de compradores que se le pase como
     * parametro
     * @param cantidad Cantidad de compradores que se desean crear
     */
    public void crearCompradores(int cantidad) {
        try {
            for (int i = 0; i < cantidad; i++) {
                Thread.sleep(rnd.nextInt(801) + 200);
                Comprador c = new Comprador(i, s, salidaLog);
                c.start();
            }
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void run() {
        this.crearCompradores(cantidad);
    }
}
