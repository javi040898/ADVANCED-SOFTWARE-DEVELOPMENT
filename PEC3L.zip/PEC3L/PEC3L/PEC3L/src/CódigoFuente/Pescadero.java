package CódigoFuente;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Exchanger;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.JTextField;

public class Pescadero extends Thread {

    private Random rnd = new Random();
    private CyclicBarrier despachado;
    private Exchanger<String> exchPesc;
    private JTextField atendiendoP;
    private CountDownLatch pausaPesc;
    private AtomicBoolean pausarPesc;
    private Logger salidaLog;
    private long t0;
    private long tf;
    private long tiempo;
    private static int nPersAtendidas = 0;
    private static long tiempoAcum = 0;

    /**
     * Constructor
     *
     * @param despachado CyclicBarrier en la que Pescadero y Cliente se podran
     * esperar mutuamente
     * @param atendiendoP JTextField donde el Pescadero indicara a quien esta
     * atendiendo
     * @param pausaPesc CountDownLatch que el Pescadero utilizara para pausarse
     * @param pausarPesc AtomicBoolean para indicar al Pescadero cuando se desea
     * que se pause
     * @param salidaLog Logger mediante el cual se escribe en el fichero de
     * texto
     * @param exchPesc Exchanger mediante el cual el Pescadero recibe el nombre
     * de quien esta atendiendo
     */
    public Pescadero(CyclicBarrier despachado, JTextField atendiendoP,
            CountDownLatch pausaPesc, AtomicBoolean pausarPesc, Logger salidaLog, Exchanger<String> exchPesc) {
        this.despachado = despachado;
        this.exchPesc = exchPesc;
        this.atendiendoP = atendiendoP;
        this.pausarPesc = pausarPesc;
        this.pausaPesc = pausaPesc;
        this.salidaLog = salidaLog;
    }

    public synchronized static long getTiempoAcum() {
        return tiempoAcum;
    }

    public void setPausaPesc(CountDownLatch pausaPesc) {
        this.pausaPesc = pausaPesc;
    }

    public synchronized static void annadirTiempo(long tiempo) {
        Pescadero.nPersAtendidas++;
        Pescadero.tiempoAcum += tiempo;
    }

    public synchronized static double mediaTiempo() {
        return tiempoAcum / nPersAtendidas;
    }

    public void setSalidaLog(Logger salidaLog) {
        this.salidaLog = salidaLog;
    }

    @Override
    public void run() {
        String idComprador = "";
        try {
            while (!interrupted()) {
                if (pausarPesc.get()) { //Si el booleano esta activo el Pescadero se bloqueara
                    pausaPesc.await();
                }
                atendiendoP.setText("");
                idComprador = exchPesc.exchange(""); //El pescadero de bloqueara hasta que llegue un Comprador y le pase su id
                atendiendoP.setText(idComprador);
                this.t0 = new Date().getTime();
                System.out.println("Pescadero atendiendo a " + idComprador + " en el instante " + t0);
                salidaLog.annadirTexto("Pescadero atendiendo a " + idComprador + " en el instante " + t0);
                Thread.sleep(2000 + rnd.nextInt(1001)); //Simulamos estar atendiendo al cliente
                this.tf = new Date().getTime();
                this.tiempo = tf - t0;
                Pescadero.annadirTiempo(tiempo);
                System.out.println(idComprador + " deja la pescaderia en el instante " + tf);
                salidaLog.annadirTexto(idComprador + " deja la pescaderia en el instante " + tf);
                System.out.println(idComprador + " ha estado en la pescaderia " + tiempo);
                salidaLog.annadirTexto(idComprador + " ha estado en la pescaderia " + tiempo);
                despachado.await(); //En este punto el cliente esperara 
            }
        } catch (InterruptedException ex) {
            System.out.println("Pescadero interrumpido");
            salidaLog.annadirTexto("Pescadero interrumpido");
            try {
                atendiendoP.setText("");
                despachado.await();
            } catch (InterruptedException ex1) {
                System.out.println(ex1.getMessage());
            } catch (BrokenBarrierException ex1) {
                System.out.println(ex1.getMessage());
            }
            catch (ArithmeticException ae) {
            salidaLog.annadirTexto("Numero de personas que han salido es 0 y no se puede obtener la media por persona");
        }

        } catch (BrokenBarrierException bbe) {
            System.out.println(bbe.getMessage());
        } 

    }
}
