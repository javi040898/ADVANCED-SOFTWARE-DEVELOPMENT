/*
 * Programa que lanza cuatro lectores y un escritor.
 * que se comunican a través de un buzón de mensajes.
 * Debe comprobarse que no se pierden los mensajes ni se leen dos veces
 */

public class PruebaBuffer1
{
    public static void main(String[] s)
    {
        Buffer buzonX = new Buffer();
        Productor A = new Productor("A ",70,buzonX);
        Productor B = new Productor("B ",70,buzonX);
        Productor C = new Productor("C ",70,buzonX);
        Consumidor jose = new Consumidor("jose", 70,buzonX);
        Consumidor ana = new Consumidor("ana", 70,buzonX);
        Consumidor maria = new Consumidor("maria", 70,buzonX);
        
        A.start();
        B.start();
        C.start();
        jose.start();
        ana.start();
        maria.start();
    }
}
