/*
 * La clase Buzon tiene que estar protegida con un cerrojo
 * El método enviaMensaje debe esperar si el buzón está lleno
 * El método recibeMensaje debe esperar si el buzón está vacío.
 * Cuando un hilo completa su operación, desbloquea a los que estén esperando
 * para que puedan continuar intentando su acción.
 */


import java.util.ArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Buffer
{
    private ArrayList<Integer> buffer = new ArrayList<Integer>();
    private int total=0;
    private Lock cerrojo=new ReentrantLock();
    private Condition bufferVacio= cerrojo.newCondition();
    private Condition bufferLleno= cerrojo.newCondition();
    
    public Buffer(){
        this.buffer= new ArrayList<Integer>();
    }

    public void introducir(String nombre, int num)
    {
        try{
            cerrojo.lock();
            while(buffer.size()>=20) //Si el buffer esta lleno los productores se dormiran
            {
                bufferLleno.await();
            }
            buffer.add(new Integer(num));
            bufferVacio.signalAll(); //Al meter un numero en el buffer despertamos a los consumidores
            
        } catch(Exception e){}
        
        finally
        {
            cerrojo.unlock();
        }
        System.out.println(nombre + " genera " + num);
        
    }

    public int sacar(String nombre)
    {
        
        int num=-1; //En el caso de que haya una excepcion el programa devuelve -1
        try{
            cerrojo.lock();
            while(buffer.isEmpty()){ //Si el buffer esta vacio dormimos a los consumidores
                try{
                    bufferVacio.await();
                }
                catch(InterruptedException ie){}
            }
        num = buffer.remove(0);
        this.suma(num);
        System.out.println(nombre + " ha leido "+ num+ " resultado= "+total);
        
        bufferLleno.signal(); //Al retirar un numero despertamos a un productor
        }
        catch(Exception e){}
        finally{
            cerrojo.unlock();
            return num;
        }

        
    }
    
    public void suma(int num){
        cerrojo.lock();
        total+=num;
        cerrojo.unlock();
    }
}