/*
 * La clase Consumidor define hilos que leen mensajes de un buzón de mensajes
 * y los muestran por pantalla.
 * El buzón y el número de mensajes, los reciben como parámetros del constructor
 * antes de terminar.
 * Entre lectura y lectura, esperan un tiempo aleatorio entre 0.5 y 1 seg.
 */

import java.util.Random;



public class Consumidor extends Thread
{
    private String prefijo;
    private int numMensajes;
    private Buffer miBuzon;
    private Random rnd = new Random();

    public Consumidor(String prefijo, int numMensajes, Buffer miBuzon)
    {
        this.prefijo=prefijo;
        this.numMensajes=numMensajes;
        this.miBuzon=miBuzon;
    }

    @Override
    public void run()
    {
        for(int i=0; i<numMensajes; i++)
        {
            try
            {
                sleep(rnd.nextInt(601)+200);
                
            } catch(InterruptedException e){ }
                miBuzon.sacar(prefijo);
                
                
        }
    }
}
