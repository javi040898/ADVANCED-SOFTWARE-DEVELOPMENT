/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaNeg;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Nacho
 */
public class AcepConexiones implements Runnable{

    private ServerSocket socket;
    private ExecutorService conexiones;
    private Exposicion exposicion;
    
    public AcepConexiones(int puerto, int nConexSimult, Exposicion exposicion) {
        try {
            this.socket = new ServerSocket(puerto);
            this.conexiones = Executors.newFixedThreadPool(nConexSimult); //Se aceptaran como maximo nConexSimult conexiones simultaneas
            this.exposicion=exposicion;
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void run() {
        try {
            while (!Thread.interrupted()) { //Mientras el hilo no sea interrumpido se seguiran aceptando conexiones
                Socket conexion = socket.accept(); 
                Cliente cliente=new Cliente(conexion, exposicion);
                conexiones.execute(cliente);
            }
            socket.close();
            conexiones.shutdownNow();
            conexiones.awaitTermination( 10, TimeUnit.SECONDS);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        
    }

}
