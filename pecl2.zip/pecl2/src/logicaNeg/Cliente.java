/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaNeg;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author Nacho
 */
public class Cliente implements Runnable {

    private Socket conexion;
    private DataInputStream entrada;
    private Exposicion exposicion;

    public Cliente(Socket conexion, Exposicion exposicion) {
        this.conexion = conexion;
        try {
            this.entrada = new DataInputStream(conexion.getInputStream());
        } catch (IOException ioe) {
            System.out.println(ioe.getMessage());
        }
        this.exposicion=exposicion;

    }

    public void run() {
        int aux;
        try {
            aux=entrada.readInt();
            while (aux != 0 || Thread.interrupted()) { //Mientras lo recibido no sea cero o el hilo no sea interrumpido se podra seguir recibiendo cosas a través del socket
                if (aux == 1) {
                    exposicion.detener();
                } else {
                    exposicion.reanudar();
                }
                aux = entrada.readInt();
            }
            entrada.close();
            conexion.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
