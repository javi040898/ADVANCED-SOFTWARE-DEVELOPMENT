package logicaNeg;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import javax.swing.JTextField;

public class Exposicion
{
    private int aforo;
    private ListaThreads colaEspera, dentro;
    private Semaphore semaforo;
    private CountDownLatch detencion; //Este CountDownLatch es el encargado de que los procesos se detengan cuando el usuario de la orden (pulse el boton de parar)
    private Boolean esperar; //Si esta puesto a true los hilos que ejecuten los metodos entrar o salir se bloquearan
    
    public Exposicion(int aforo, JTextField tfEsperan, JTextField tfDentro)
    {
        this.aforo=aforo;
        semaforo=new Semaphore(aforo,true);
        colaEspera=new ListaThreads(tfEsperan);
        dentro=new ListaThreads(tfDentro);
        this.detencion=new CountDownLatch(1); //Inicilizamos el contador a 1 para que solo sea neceserio que se ejecute una vez el metodo countDown una vez, concretamente cuando el usuario pulse el boton de reanudar
        this.esperar=false;
    }
    
    public void entrar(Visitante v)
    {
        synchronized(esperar)
            {
                if(esperar) //Si esperar es true los hilos se bloquearan
                {
                    try {
                        detencion.await();
                    } catch (InterruptedException ex) {}
                }
            }
        colaEspera.meter(v);
        try
        {
            synchronized(esperar)
            {
                if(esperar) //Si esperar es true los hilos se bloquearan
                {
                    detencion.await(); 
                }
            }
            semaforo.acquire();
        } 
        catch(InterruptedException e){ }
        colaEspera.sacar(v);
        dentro.meter(v);
    }

    public void salir(Visitante v)
    {
        synchronized(esperar) 
        {
            if(esperar) //Si esperar es true los hilos se bloquearan
            {
                try
                {
                    detencion.await();
                }
                catch(InterruptedException ie){}
            }
        }
        dentro.sacar(v);
        semaforo.release();
    }
    
    public void mirar(Visitante v)
    {
        try
        {
            Thread.sleep(2000+(int)(3000*Math.random()));
        } 
        catch (InterruptedException e){ }
    }
    
    
    public void detener()
    {
        synchronized(esperar)
        {
            esperar=true; //Ponemos esperar a true para que los hilos se bloqueen
        }
    }
    
    public void reanudar()
    {
       esperar=false; //Ponemos esperar a false para que ningun hilo entre mas a la zona donde esta el CountDownLatch
       detencion.countDown(); //Hacemos countDown para liberar a los hilos bloqueados
       detencion=new CountDownLatch(1); //Y como el CountDownLatch no es reutilizable volvemos a crear uno nuevo
    }
}
